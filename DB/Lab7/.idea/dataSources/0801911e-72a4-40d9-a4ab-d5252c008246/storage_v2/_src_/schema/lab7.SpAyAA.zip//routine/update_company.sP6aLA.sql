create procedure update_company(IN old_company_name_in varchar(50), IN new_company_name_in varchar(50))
  BEGIN 

DECLARE msg VARCHAR(50);

IF EXISTS (SELECT * FROM add_company WHERE commany_name = old_company_name_in)
THEN UPDATE add_company SET company_name = new_company_name_in
WHERE company_name = old_company_name_in; SET msg = 'OK';

ELSE SET msg = 'No such company';
END IF;
END;

