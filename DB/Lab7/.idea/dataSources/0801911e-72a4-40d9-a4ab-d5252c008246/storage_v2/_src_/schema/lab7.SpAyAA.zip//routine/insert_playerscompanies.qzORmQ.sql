create procedure insert_playerscompanies(IN last_name_in    varchar(30), IN first_name_in varchar(30),
                                         IN company_name_in varchar(50))
  BEGIN
DECLARE msg VARCHAR(50);
-- checks if player exists
IF NOT EXISTS(SELECT * FROM football_player WHERE last_name = last_name_in AND first_name = first_name_in) 
THEN SET msg = 'There is no such football player';
-- checks if company exists
ELSEIF NOT EXISTS(SELECT * FROM add_company WHERE company_name = company_name_in)
THEN SET msg = 'There is no such company';
-- checks if such combinations exists
ELSEIF EXISTS(
SELECT * FROM playerscompanies WHERE
last_name = (SELECT last_name FROM football_player WHERE last_name = last_name_in AND first_name = first_name_in) AND
first_name = (SELECT first_name FROM football_player WHERE last_name = last_name_in AND first_name = first_name_in) AND
company_name = (SELECT company_name FROM add_company WHERE company_name = company_name_in)
) THEN SET msg = 'This company already has this player';

ELSE INSERT INTO playerscompanies VALUE(
(SELECT last_name FROM football_player WHERE last_name = last_name_in AND first_name = first_name_in),
(SELECT first_name FROM football_player WHERE last_name = last_name_in AND first_name = first_name_in),
(SELECT company_name FROM add_company WHERE company_name = company_name_in)
); SET msg = 'OK'; END IF;

SELECT msg AS message;

END;

