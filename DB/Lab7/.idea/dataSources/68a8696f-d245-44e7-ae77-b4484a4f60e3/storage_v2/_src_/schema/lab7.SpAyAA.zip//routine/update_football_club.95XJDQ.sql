create procedure update_football_club(IN old_club_name_in varchar(30), IN new_club_name_in varchar(30))
  BEGIN

DECLARE msg VARCHAR(50);

IF EXISTS (SELECT * FROM football_club WHERE club_name = old_club_name_in) 
THEN UPDATE football_club SET club_name = new_club_name_in
WHERE club_name = old_club_name_in; SET msg = 'OK';

ELSE SET msg = 'No such club';
END IF;
SELECT msg AS message;

END;

