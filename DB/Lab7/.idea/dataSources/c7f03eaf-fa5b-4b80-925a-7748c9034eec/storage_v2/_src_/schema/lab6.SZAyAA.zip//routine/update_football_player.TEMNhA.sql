create procedure update_football_player(IN old_last_name_in varchar(30), IN old_first_name_in varchar(30),
                                        IN new_last_name_in varchar(30), IN new_first_name_in varchar(30))
  BEGIN

DECLARE msg VARCHAR(50);

IF EXISTS (SELECT * FROM football_player WHERE last_name = old_last_name_in AND first_name = old_first_name_in) 
THEN UPDATE football_player SET last_name = new_last_name_in, first_name = new_first_name_in 
WHERE last_name = old_last_name_in AND first_name = old_first_name_in; SET msg = 'OK';

ELSE SET msg = 'No such player';
END IF;
SELECT msg AS message;

END;

